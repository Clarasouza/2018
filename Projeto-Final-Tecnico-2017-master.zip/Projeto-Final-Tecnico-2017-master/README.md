# Projeto-Final-T-cnico-2017
Trabalho Prático Integrador  Este trabalho tem por finalidade exercitar os conceitos e técnicas trabalhados nas seguintes disciplinas: Desenvolvimento Web; Fundamentos de Informática; Lógica de Programação;
