<?php

class ControleSalario
{
    public function ControlaSalarios( Funcionario $funcionario){

        if ($funcionario->salario < 980){
            echo "O funcionario ganha menos que um salario minimo";
        }
    }
}