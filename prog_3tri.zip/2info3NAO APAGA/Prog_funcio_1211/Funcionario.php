<?php

class Funcionario{
	private $nome;
	private $salario;

	public function __construct(string $nome, float $salario = 987.65){
		$this->setNome($nome);
		$this->setSalario($salario);
		
	}

	public function __toString(){
		return "";
	}

	public function setNome($nome){

	}

	public function getNome(){
		
	}

	public function setSalario($valor){
		$this->salario = $valor;

	}

	public function getSalario(){
		
	}
}









class Funcionario2{

    public $salario;
    public $departamento;
    public $dataEntrada;


    public function recebeAumento;
    $this->salario = $this->salario + ($this->salario * 0.15);
}

    public function calculaGanhoAnual;
        //fazer metodo
}



class Gerente extends Funcionario {

    public $senha;
    public function mostra(){
        echo $this-> departamento;
    }
}

$serjao_berranteiro = new Gerente();
$serjao_berranteiro->salario = 5000;
$serjao_berranteiro-> recebeAumento();

/*

$gerente = new Funcionario ("Jeff", 2500);
print_r($gerente);


A partir da -> temos a permissao de escolher entre todos os dados salvos na memoria 
*/

//vantagens= aproveitar o codigo; poliformismo- posso me referir ao sergio como funcionario ou como gerente