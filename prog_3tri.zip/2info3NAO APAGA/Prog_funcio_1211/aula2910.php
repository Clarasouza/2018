<?php

    class Conta{
        public    $numero;
        protected $dono;
        public    $saldo;
        private   $limite;
        private   $salario;

        public function saca($valor){

            if ($valor <= $this->saldo) {
                $novoSaldo = $this->saldo - $valor;
                $this->saldo = $novoSaldo;
                return true;
            }else{
                return false;
            }
        }

        public function informarLimite(float $salario){
            $calcular_limite = $salario * 0.1;
            $this->limite = $calcular_limite;

        }

        public function retornarLimite(){
            return $this->limite;
        }

        public function informarNome(sring $dono){
            if(strlen($dono)>1){
                retur;
            }

        }

        public function deposita($valor){
            $novoSaldo = $this->saldo + $valor;
            $this->saldo = $novoSaldo;
        }

        public function transferePara(Conta $contaDestino, $valor){

            $deu_certo = $this->saca($valor);

            if ($deu_certo){
                $contaDestino->deposita($valor);
            }


        }
    }

class ContaPoupanca extends Conta{

}


/*

    $minha_conta = new Conta;
    $minha_conta->limite = 500;
    $minha_conta->dono = "Paulo";
    $minha_conta->saldo = 1000;

    $a_conta = new Conta;
    $a_conta->limite = 500;
    $a_conta->dono = "Aline";
    $a_conta->saldo = 1000000;

    $minha_conta->transferePara($a_conta, 6000);


$minha_conta->saca(200);
$minha_conta->deposita(50);

$deu_Certe = $minha_conta->saca(2000);

if ($deu_Certo){
    echo "o saldo foi realizado com sucesso!";
}

*/


//    FUNCTION nas classas sao chamadas de METODOS
// para acessar cada um dos cara ali (dono, saldo ,etc..) tenho que usar o This, e só uso THIS dentro de métodos
//    $endereco = new Conta;
//    $endereco-> dono= "Jefferson";
//para usar os valores de uma classe pŕeciso criar um objeto, por isso o nome
