<!doctype html>
<html lang="en">
<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css">
    <link rel="stylesheet" href="../../assets/dashboard.css">

    <title>Hello, world!</title>

</head>
<body>

    <nav class="navbar navbar-dark fixed-top bg-dark flex-md-nowrap p-0 shadow">
        
        <a class="navbar-brand col-sm-3 col-md-2 mr-0" href="#">{Resenha Upgrade}</a>

        <ul class="navbar-nav px-3">
            <li class="nav-item text-nowrap">
                <a class="nav-link" href="#">Sign out</a>
            </li>
        </ul>
    </nav>

    <div class="container-fluid">
    <div class="row">
    
        <?php require "sidebar.php"; ?>

        <main role="main" class="col-md-9 ml-sm-auto col-lg-10 px-4">

            <h1>Hello, <?= $teste?>!  </h1>

            <div class="table-responsive">
                <table class="table table-sm">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>nome</th>
                            <th>email</th>
                            <th>opções</th>
                        </tr>
                    </thead>
                    <tbody>

                        <?php foreach ($usuarios as $usuario): ?>
                            <tr>
                                <th scope="row"><?= $usuario['id'] ?></th>
                                <td><?= $usuario['nome'] ?></td>
                                <td><?= $usuario['email'] ?></td>
                                <td>
                                    <a href="http://localhost/2info1/resenha_upgrade/app/controllers/usuario.php?acao=editar&id=<?= $usuario['id'] ?>">editar</a>
                                    <a href="http://localhost/2info1/resenha_upgrade/app/controllers/usuario.php?acao=excluir&id=<?= $usuario['id'] ?>">excluir</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>

                    </tbody>
                </table>
            </div>

        </div>
    </main>
</div>
</div>

<!-- Bootstrap core JavaScript -->
<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js"></script>
<script>window.jQuery || document.write('<script src="../../assets/js/vendor/jquery-slim.min.js"><\/script>')</script>
<script src="../../assets/js/bootstrap.min.js"></script>

<!-- Icons -->
<script src="https://unpkg.com/feather-icons/dist/feather.min.js"></script>
<script>
  feather.replace()
</script>

</body>
</html>