<nav class="col-md-2 d-none d-md-block bg-light sidebar">
  <div class="sidebar-sticky">
    <ul class="nav flex-column">

      <li class="nav-item">
        <a class="nav-link" href="#">
          <span data-feather="file"></span>
          Listar Resenhas
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          <span data-feather="file"></span>
          Cadastrar Resenhas
        </a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="#">
          <span data-feather="users"></span>
          Usuários
        </a>
      </li>

      <li class="nav-item">
        <a class="nav-link" href="#">
          <span data-feather="users"></span>
          Cadstrar Usuários
        </a>
      </li>

    </ul>



  </div>
</nav>