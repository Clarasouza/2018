<?php 


	require __DIR__ . "/app/connection/Connection.php";
	$sql = file_get_contents("config/resenha_upgrade.sql");

	$con = new PDO("mysql:host=localhost;dbname=resenha_upgrade3;", "root","");
        $con->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

	$con->exec($sql);


	print "\n<br/>----------------------------------------------------------------\n<br/>";
	echo "- Instalado com sucesso";
	print "\n<br/>----------------------------------------------------------------\n<br/>";

