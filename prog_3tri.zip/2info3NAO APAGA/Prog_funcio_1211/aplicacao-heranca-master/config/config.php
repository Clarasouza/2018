<?php

	//arquivo de configuracao