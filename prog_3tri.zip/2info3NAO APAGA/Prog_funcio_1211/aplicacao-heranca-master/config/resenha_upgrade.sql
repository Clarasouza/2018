-- phpMyAdmin SQL Dump
-- version 4.8.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: 24-Nov-2018 às 01:46
-- Versão do servidor: 10.1.33-MariaDB
-- PHP Version: 7.1.18

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `resenha_upgrade`
--
CREATE DATABASE IF NOT EXISTS `resenha_upgrade` DEFAULT CHARACTER SET utf8 COLLATE utf8_general_ci;
USE `resenha_upgrade`;

-- --------------------------------------------------------

--
-- Estrutura da tabela `rating`
--

CREATE TABLE IF NOT EXISTS `rating` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `rate` int(11) NOT NULL,
  `id_user` int(11) NOT NULL,
  `id_review` int(6) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `rating_user` (`id_user`),
  KEY `rating_review` (`id_review`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `rating`
--

INSERT INTO `rating` (`id`, `rate`, `id_user`, `id_review`) VALUES
(1, 2, 6, 1);

-- --------------------------------------------------------

--
-- Estrutura da tabela `resenhas`
--

CREATE TABLE IF NOT EXISTS `resenhas` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `titulo` varchar(64) NOT NULL,
  `jogo` varchar(64) NOT NULL,
  `descricao` text,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `resenhas`
--

INSERT INTO `resenhas` (`id`, `titulo`, `jogo`, `descricao`) VALUES
(1, 'Uma análise superficial sobre Stick it to the Man', 'Stick it to the Man', 'Com uma arte peculiar, que mescla dioramas com o traço grotesco típico de Tim Burton, Stick it to the Man é um point and click adventure que aposta no absurdo para entreter o jogador. Contudo, tanto o design de seus enigmas quanto o humor que permeia sua história são marcados pela repetição e pela condescendência, desperdiçando o potencial de seu curioso visual.\r\n\r\nO protagonista do título é um jovem chamado Ray que, um dia, é acertado por um misterioso objeto e acorda com a habilidade de ler a mente das pessoas, graças a um braço rosa mágico que agora sai de sua cabeça. Com isso, ele acaba sendo perseguido por uma organização secreta, embora sua preocupação maior seja apenas conseguir reencontrar sua namorada em casa.'),
(2, 'Outra resenha bem trabalhada', 'Super Mario Bros', 'Super Mario Bros. é um jogo eletrônico lançado pela Nintendo em 1985. Considerado um clássico, Super Mario Bros. foi um dos primeiros jogos de plataforma com rolagem lateral, recurso conhecido em inglês como side-scrolling');

-- --------------------------------------------------------

--
-- Estrutura da tabela `usuarios`
--

CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(6) NOT NULL AUTO_INCREMENT,
  `nome` varchar(64) NOT NULL,
  `email` varchar(64) NOT NULL,
  `senha` varchar(64) NOT NULL,
  `avatar` varchar(64) NOT NULL DEFAULT 'default.jpg',
  `tipo` int(1) NOT NULL DEFAULT '1',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8;

--
-- Extraindo dados da tabela `usuarios`
--

INSERT INTO `usuarios` (`id`, `nome`, `email`, `senha`, `avatar`, `tipo`) VALUES
(6, 'Rocky', 'rocky@balboa.com', 'senha', 'rocky.jpg', 2),
(9, 'Cobra', 'cobra@stallone.com', 'senha', 'cobra.jpg', 2),
(10, 'Jefferson Chaves', 'jefferson.chaves@ifc.edu.br', '123', 'giphy.gif', 1);

--
-- Constraints for dumped tables
--

--
-- Limitadores para a tabela `rating`
--
ALTER TABLE `rating`
  ADD CONSTRAINT `rating_review` FOREIGN KEY (`id_review`) REFERENCES `resenhas` (`id`),
  ADD CONSTRAINT `rating_user` FOREIGN KEY (`id_user`) REFERENCES `usuarios` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
