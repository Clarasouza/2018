<?php

	//arquivo de configuracao


	