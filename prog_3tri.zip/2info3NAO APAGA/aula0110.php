classe: define os atributos e metodos, nao é um objeto. normalmente é um subsrantivo e precisa ser salvo no seu banco de dados representacao compartilhada de algumas coisas, ex: cadeira tem que ter pernas, asento,encosto etc.
celular é uma classe, todo celular tem atributos em comun etc. porem iphone é um objeto.
a partir de celular eu posso representar diversos outros. cadeira e estudante tbm.

objeto: coisa material ou abstrata que pode ser percebida pelos sentidos 

abstração: trazer conceitos do mundo real para a programação

dado > infrmação > conhecimento
39graus > de temperatura > Virose 