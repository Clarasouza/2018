<?php
include("cabecalho.php");

?>
	<div class="coluna10">.</div>

		<article class="coluna80">
		<img src="imagens/chat.png" class="imagem">
		

<section class="cem">
	
			<section class='cinquenta1'>
				<section class='fatos'>
					<h2 id='letra17'> Inicio das Aulas: </h2>
					<h2 id='letra18'> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Morbi gravida libero nec velit. Morbi scelerisque luctus velit. Etiam dui sem, fermentum vitae, sagittis id, malesuada in, quam. Proin mattis lacinia justo. Vestibulum facilisis auctor urna. Aliquam in lorem sit amet leo accumsan lacinia. </h2>
				</section>
				<section class='transparente'></section>
				<section class='fatos'>
					<h2 id='letra17'> Férias: </h2>
					<h2 id='letra18'> Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Nullam feugiat, turpis at pulvinar vulputate, erat libero tristique tellus, nec bibendum odio risus sit amet ante. Aliquam erat volutpat. Nunc auctor. Mauris pretium quam et urna. Fusce nibh. Duis risus.  </h2>
				</section>
				<section class='transparente'></section>
				<section class='fatos'> 
					<h2 id='letra17'> Viagens de Estudos: </h2>
					<h2 id='letra18'>Aenean placerat. In vulputate urna eu arcu. Aliquam erat volutpat. Suspendisse potenti. Morbi mattis felis at nunc. Duis viverra diam non justo. In nisl. Nullam sit amet magna in magna gravida vehicula. Mauris tincidunt sem sed arcu. Nunc posuere. Nullam lectus justo, vulputate eget, mollis sed, tempor sed, magna.</h2>
				</section>
			</section>
		
			<section class='cinquenta2'>
				<section class='transparente'></section>
				<section class='fatos'> 
					<h2 id='letra17'> Adaptação: </h2>
					<h2 id='letra18'> In sem justo, commodo ut, suscipit at, pharetra vitae, orci. Duis sapien nunc, commodo et, interdum suscipit, sollicitudin et, dolor. Pellentesque habitant morbi tristique senectus et netus et malesuada fames ac turpis egestas. Aliquam id dolor.Litora torquent per conubia nostra, per inceptos hymenaeos. Mauris dictum facilisis augue.</h2>
				</section>
				<section class='transparente'></section>
				<section class='fatos'> 
					<h2 id='letra17'> Painel Integrador: </h2>
					<h2 id='letra18'> Morbi a metus. Phasellus enim erat, vestibulum vel, aliquam a, posuere eu, velit. Nunc tincidunt ante vitae massa. pede. Nulla accumsan, elit sit amet varius semper, nulla mauris mollis quam. Etiam commodo dui eget wisi. Donec iaculis gravida nulla. Donec quis nibh at felis congue commodo. Etiam bibendum elit eget </h2>
				</section>
				<section class='transparente'></section>
				
			</section>
		</section>

	

<?php
include("rodape.php");

?>