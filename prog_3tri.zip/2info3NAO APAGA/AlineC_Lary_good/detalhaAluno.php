<?php

include("cabecalho.php");

?>

	<div class="coluna10">.</div>

	<!-- conteudo principal -->
	<article class="coluna80">


<?php

	include("alunos.php");


//recupera o codigo enviado via metodo get
	$matricula = $_GET['cod'];

//chama funcao passando o codigo do professor
	$aluno = buscaAluno($matricula);

?>
	
	<div class="clicavel" id="foto">
		<img src="<?=$aluno['foto'] ?>">
	</div>

	<div class="modal1 foto escondido">
		

		<div class="fechar">X</div>

		<img src="<?=$aluno['foto'] ?>"/>

		</div>
	</div>


	<section class="dados">
			<h2>Nome: <?=$aluno['nome'] ?></h2>
			<p>E-mail: <?=$aluno['email'] ?></p>
			<p>Turma: <?=$aluno['turma'] ?></p>

	</section>


</article>

<?php

include("rodape.php");


?>
