<?php

include("cabecalho.php");
	

	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="1; url=ofertas.php">');
	}else{


	$turma = $_POST['turma'];
	$materia = $_POST['materia'];
	$siape = $_POST['siape'];

	$novo = fopen("dados/ofertas.csv", "a+");
	
	fwrite( $novo , "\n2017," .$turma. "," .$materia. "," .$siape.",");

	fclose($novo);

	echo('<h1>Cadastro feito com suesso!</h1>');

	echo('<meta http-equiv="refresh" content="1; url=oferta.php">');
	
	}

	include("rodape.php")

?>