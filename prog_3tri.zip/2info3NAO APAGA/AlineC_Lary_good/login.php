<?php

include('cabecalho.php');

//LOGIN.PHP

	//inicia a sessao/SESSION
	session_start();

//capturando os dados enviados por POST
	$login = $_POST['login'];
	$senha = $_POST['senha'];

//admin - admin

	if($login == 'admin' and $senha == 'admin'){
		
		//logou como administrador e acertou a senha
		echo("<h1>Olá, Administrador</h1>");

		//guardando informacoes na SESSAO
		$_SESSION['nome'] = "Administrador";
		$_SESSION['login'] = 'admin';

		//redireciona para a pagina do administrador
		echo('<meta http-equiv="refresh" content="1; url=oferta.php">');

	}else{
		echo("<h1>Dados Inválidos</h1>");
		//redireciona para a página inicial
		echo('<meta http-equiv="refresh" content="1; url=oferta.php">');
	}

include("rodape.php");
//linha 11 - select * from usuarios where login=$login and senha=$senha (consulta sql=banco de dados)
?>