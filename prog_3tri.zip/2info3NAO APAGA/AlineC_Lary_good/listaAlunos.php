<?php


include("cabecalho.php");

	include("alunos.php");



?>

	<div class="coluna10">.</div>
	<article class="coluna80">

	<h2>Alunos 1info:</h2>

<?php
	


	for($i=1; $i<4; $i++){
		$turma='1info'. $i;

?>
		<section class="lista">
		<h2 class="turma" id="<?=$turma?>"><?=$turma?></h2>
		<ul class="<?=$turma?> escondido">

<?php




	$lista = listaAlunosTurma($turma);

	

	foreach($lista as $aluno){
		echo('<li ><a href="detalhaAluno.php?cod='.$aluno['matricula'].'">' .$aluno['nome'].'</a></li>');
	}

?>

	</ul>
	</section>


<?php

}

?>


	</article>

<?php
include("rodape.php");
?>