<?php

	include("../professores.php");


	$p1= buscaProfessores("1091826");
	print_r($p1['email']);


?>