<?php

include("cabecalho.php");


	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="1; url=oferta.php">');
	}else{

?>

	<div class="coluna10">.</div>

	<!-- conteudo principal -->
	<article class="coluna80">

	<section class="lista">
	
	

	<form action="insereMateria.php" method="post" enctype="multipart/form-data">

		<label for="materia">Insira a nova disciplina:</label>
		<input type="text" name="materia"  class="input espaco">

		<input type="submit" name="gravar"  class="input espaco">

	


	</form>
	
	</article>

	</section>

<?php
}
include("rodape.php");
?>