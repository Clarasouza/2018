<?php
include("disciplina.php");
include("cabecalho.php");

	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="1; url=oferta.php">');
	}else{


$materia = $_POST['materia'];

$lista = listaDisciplinas();

$tamanho = sizeof($lista);
$codigo = $tamanho + 1;

$novo = fopen("dados/disciplinas.csv", "a+");
	
	fwrite( $novo , "\n" .$codigo. "," .$materia. ",");

	fclose($novo);

	echo('<h1>Cadastro feito com suesso!</h1>');

	echo('<meta http-equiv="refresh" content="1; url=oferta.php">');
	
	}

	include("rodape.php")




?>