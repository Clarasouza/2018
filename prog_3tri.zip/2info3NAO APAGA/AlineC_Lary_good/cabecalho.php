<?php

session_start();


?>


<!DOCTYPE html>
<html>
<head>
	<script type="text/javascript" src="js/jquery.js"></script>
	<script type="text/javascript" src="js/script.js"></script>
	<link rel="stylesheet" type="text/css" href="css/completo.css">
	<link rel="icon" href="imagens/icone.png" type="image/x-icon"/>


	<title>Agenda</title>
	<meta charset="utf-8">
</head>
<body>
	<!-- cabeçalho -->
	<header>
		<a href="index.php"><img src="imagens/logoboni.png" id="logo"/></a>


	</header>

	<div class="login">

<?php

	if(!isset($_SESSION['login'])){

?>

		<form action="login.php" method="post">
		
		<label for="login">Login:</label>
		<input type="text" name="login" class="input">

		<label for="senha">Senha:</label>
		<input type="password" name="senha" class="input">
		
		<input type="submit" name="entrar" class="input">


	</form>

<?php
}else{
?>
	<h2>Olá, <?=$_SESSION['nome']?>!</h2>
	<p><a href="logout.php">Sair</a></p>
	
<?php
}
?>
	</div>


	<div class='divider'></div>

	<!-- menu -->
	
	<nav class="menu">
		<section class="item menu drop maiorzinho" id="item1">
			<h1 class="letra">Cadastros</h1>

			<div class="submenu item1 escondido">

				<a href="formAlunos.php">Cadastrar Aluno</a>

			</div>

			<div class="submenu item1 escondido ">

				<a href="formProfessor.php">Cadastrar Professor</a>

			</div>

			<div class="submenu item1 escondido">

				<a href="formMateria.php">Cadastrar Disciplinas</a>

			</div>

			<div class="submenu item1 escondido">

				<a href="formDisciplina.php">Atualizar materia por disciplina</a>
			</div>


		</section>
		
			<a href=""><section class="item menu">
				<h1 class="letra">Todas Tarefas</h1>
			</section></a>

			<a href="oferta.php"><section class="item menu">
				<h1 class="letra">Tarefas por Disciplina</h1>
			</section></a>

			<a href=""><section class="item menu">
				<h1 class="letra">Tarefas por Data</h1>
			</section></a>

			<a href="listaProfessores.php"><section class="item menu ">
				<h1 class="letra">Professores</h1>
			</section></a>

			<a href="listaAlunos.php"><section class="item menu">
				<h1 class="letra">Colegas</h1>
			</section></a>
	</nav>
	<div class='divider'></div>

	<!-- colunas para centralizar -->

