<?php

	include("cabecalho.php");

	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="1; url=listaProfessores.php">');
	}else{


	$origem = $_FILES['foto']['tmp_name'];


	$partesNome = explode(' ', $_POST['nome']);
	$primeiroNome = $partesNome[0];
	$sobreNome = end($partesNome);



	$nomeArquivo = $primeiroNome. "." .$sobreNome;
	$extensao = explode('/', $_FILES['foto']['type']);


	
	$destino = 'imagens/professores/'.$nomeArquivo.".".$extensao[1];
	

	move_uploaded_file($origem, $destino);



	$nominho = fopen("dados/professores.csv", "a+");
	
	fwrite( $nominho , "\n" .$_POST['siape'].",".$_POST['nome'].",".$_POST['email'].",".$destino);
	

	fclose($nominho);

	echo('<h1>Cadastro feito com suesso!</h1>');


	echo('<meta http-equiv="refresh" content="1; url=listaProfessores.php">');

	}
	

	include("rodape.php");

?>