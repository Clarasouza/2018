<!-- colunas para centralizar -->
	<div class="coluna10">.</div>
</body>
</html>