$(document).ready(function(){
	$('.clicavel').click(function(){
		var id;
		id=$(this).attr('id');
		$('.'+id).removeClass('escondido');
	
	})

		$('.fechar').click(function(){
			$('.modal1').addClass('escondido');
		})



	$(".drop").hover(function(){
		var id;

		
		id=	$(this).attr('id');
		
		$(".submenu." +id).toggleClass('escondido');
	})
	
	



		$('.turma').click(function(){
			var id;
		id=	$(this).attr('id');
		$('.'+id).toggleClass('escondido');
	})	



})