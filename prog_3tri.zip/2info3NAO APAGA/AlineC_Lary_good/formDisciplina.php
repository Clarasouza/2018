<?php

include("cabecalho.php");
include("professores.php");
include("disciplina.php");


	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="2; url=oferta.php">');
	}else{

?>

	<div class="coluna10">.</div>

	<!-- conteudo principal -->
	<article class="coluna80">

	<section class="lista">
	
	

	<form action="insereDisciplina.php" method="post">

		
		<label for="turma">Turma:</label>
		<select name="turma"  class="input espaco">
			<option>1info1</option>
			<option>1info2</option>
			<option>1info3</option>
		</select>
		

		</br>

		<label for="materia">Disciplina:</label>

<?php
	$disciplinas = listaDisciplinas();
?>
		<select name="materia" class="input espaco">
<?php
	foreach ($disciplinas as $disciplina) {
		echo('<option value="'.$disciplina['codigo'].'">'.$disciplina['nome'].'</option>');
	}

?>		
			
		</select>
		</br>
	



		<label for="siape">Professor:</label>
<?php
	$professores = listaProfessores();
?>
		<select name="siape" class="input espaco">
<?php
	foreach ($professores as $professor) {
		echo('<option value="'.$professor['siape'].'">'.$professor['nome'].'</option>');
	}

?>		
		</select>		

		</br>
		

		<input type="submit" name="gravar" class="input espaco">


	</form>
	
	</article>
	</section>
	

<?php
}
include("rodape.php");
?>


