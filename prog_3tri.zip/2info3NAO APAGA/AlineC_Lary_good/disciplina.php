<?php

function listaDisciplinas(){
	
	$disciplinas = array();
	$dados = file("dados/disciplinas.csv");
	
	foreach( $dados as $posicao=>$linha){
		
		$colunas = explode(",",$linha);
		
		if($posicao!=0){

			$disciplina['codigo'] = $colunas[0];
			$disciplina['nome'] = $colunas[1];

			$disciplinas[] = $disciplina;
		}
	}
	return $disciplinas;
}
	

function buscaDisciplinas($num){
	
	$disciplina = array();
	$dados = file("dados/disciplinas.csv");
	
	foreach( $dados as $linha){
		
		$colunas = explode(",",$linha);
		
		if ($colunas[0]==$num){
			$disciplina['codigo'] = $colunas[0];
			$disciplina['nome'] = $colunas[1];
		}
	}
	return $disciplina;
}

function ofertas($ano,$turma){

	$dados = file("dados/ofertas.csv");
	$ofertas=array();

	
	
	foreach( $dados as $linha){
		
		$colunas = explode(",",$linha);

		if($colunas[0]==$ano and $colunas[1]==$turma){
				$oferta = array();
				$oferta['disciplina'] = $colunas[2];
				$oferta['professor'] = $colunas[3];
				$ofertas[] = $oferta;
		}
	}

	return $ofertas;
}

/*
$d1=ofertas(2017,'1info1');
print_r($d1);

$d1=listaDisciplinas();
print_r($d1);
*/



?>