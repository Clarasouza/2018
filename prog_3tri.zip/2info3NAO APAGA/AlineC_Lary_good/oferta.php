<?php

include("cabecalho.php");

include("disciplina.php");

include("professores.php");

?>

	<div class="coluna10">.</div>
	<article class="coluna80">
	<h2>Tarefas por Disciplina:</h2>

<?php
	


	for($i=1; $i<4; $i++){
		$turma='1info'. $i;

?>
		<section class="lista">
		<h2><?=$turma?></h2>
		<ul>

<?php
	



	$lista = ofertas('2017',$turma);

	

	foreach($lista as $oferta){

		$materia = buscaDisciplinas($oferta['disciplina']);
		$professor = buscaProfessores($oferta['professor']);
		echo('<li>'.$materia['nome'].'- <a href="detalhaProfessor.php?cod='.$professor['siape'].'">' .$professor['nome'].'</a></li>');
	}


?>

	</ul>
	</section>


<?php

}
?>



	</article>

<?php
include("rodape.php");
?>

