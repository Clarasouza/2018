<?php

include("cabecalho.php");


	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="1; url=oferta.php">');
	}else{

?>

	<div class="coluna10">.</div>

	<!-- conteudo principal -->
	<article class="coluna80">

	<section class="lista">
	
	

	<form action="insereAluno.php" method="post" enctype="multipart/form-data">

		<label for="matricula">Matrícula:</label>
		<input type="text" name="matricula" class="input espaco">

		</br>


		<label for="nome">Nome:</label>
		<input type="text" name="nome" class="input espaco">

		</br>

		<label for="turma">Turma:</label>
		<input type="text" name="turma" class="input espaco">
		
		</br>

		<label for="email">E-mail:</label>
		<input type="email" name="email" class="input espaco">

		</br>
		
		<label for="foto">Foto:</label>
		<input type="file" name="foto" class="input espaco">

		<input type="submit" name="gravar"  class="input espaco">


	</form>
	
	</article>

	</section>

<?php
}
include("rodape.php");
?>

