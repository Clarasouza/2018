<?php

	include("cabecalho.php");

	if(!isset($_SESSION['login'])){
		echo('<h1>Acesso Negado!</h1>');
		echo('<meta http-equiv="refresh" content="1; url=listaAlunos.php">');
	}else{

//mover o arquivo recebido para o destino

	$origem = $_FILES['foto']['tmp_name'];
	


	$partesNome = explode(' ', $_POST['nome']);
	$primeiroNome = $partesNome[0];
	$sobreNome = end($partesNome);



	$nomeArquivo = $primeiroNome. "." .$sobreNome;
	$extensao = explode('/', $_FILES['foto']['type']);


	
	$destino = 'imagens/alunos/'.$nomeArquivo.".".$extensao[1];

	move_uploaded_file($origem, $destino);

//termina aqui

	$novo = fopen("dados/alunos.csv", "a+");
	
	fwrite( $novo , "\n" .$_POST['matricula'].",".$_POST['nome'].",".$_POST['turma']. "," .$_POST['email']. "," .$destino);
	

	fclose($novo);

	echo('<h1>Cadastro feito com suesso!</h1>');

	echo('<meta http-equiv="refresh" content="1; url=listaAlunos.php">');
	
	}
	
	include("rodape.php");

?>