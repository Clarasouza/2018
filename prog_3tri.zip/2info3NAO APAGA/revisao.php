// Revisão prova segundo trimestre - 22.08

- Cliente = navegador, exemplo: google chrome 

- Servidor = programa que recebe uma requisição  e da uma resposta, ta na rede. Exemplo: Apache

- http:// = protocolo (define regras), a comunicação entre a internet e o servidor é feito por ele

- 80 para http ou 443 para https = porta para o apache

-Apache é um servidor:
	- "public_html" para selecionar pastas especificas (sites) pra ficar no navegador, não seria seguro todas as pastas do computador ficarem disponiveis

	- Se não tiver o recurso, exemplo "facebook.com/index.php", então leve direto para paǵina principal

	- 200 porta para o index

	- O Apache é necessário para realizar a comunicação entre o cliente e suas requisições. 

	- 300 é redirecionar


- Statless: não guarda status, o que seria mt incomodo validar seus dados todas as vezes que vc fosse fazer algo somente para logados. Para resolver esse problema criaram as sessões:
	- No cliente a info é guardada e no servidor também, depois que a sessão foi feita.
	- Sessão: fecha o navegador acaba
	- Cookie: dura um pouco mais