<?php

class Connection{


    //atributos
    public $connection;

    public function __construct(){

        $this->connection = new PDO("mysql:host=localhost;dbname=resenha_upgrade;", "root", "root");
        //oq é this:
    }

    public function getConnection(){
        return $this->connection;
    }
}