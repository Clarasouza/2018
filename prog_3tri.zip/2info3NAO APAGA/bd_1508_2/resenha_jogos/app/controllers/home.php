<?php

    require __DIR__."../models/Usuario.php";
    //__dir__ dis em que  pasta que tá

    //objeto da classe usuario
    $users = new Usuario();
    $listaUsuarios = $users->todos();

    print_r($listaUsuarios);