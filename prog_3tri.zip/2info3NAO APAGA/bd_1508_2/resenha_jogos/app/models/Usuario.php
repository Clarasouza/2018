<?php

require __DIR__."../conexao/Connection.php";

class Usuario{

    //ATRIBUTOS DA CLASSE
    public $id;
    public $nome;
    public $usuario;
    public $senha;
    public $tipoUsuario; // 1 para comum e 2 para admin

    public $conexao;

    //COMPORTAMENTOS
    public function __construct(){
        $this->tipoUsuario = 1;
        $conexao_objeto= new Connection();
        //o atributo $this->conexqao agora sabe como se
        //comunicar com o banco de dados
        $this->conexao = $conexao_objeto->getConnection ();
    }


    public function exibe(){

        echo "usuario {$this->nome} foi criado com o tipo {$this->tipoUsuario} e id {$this->id} \n";

    }

    public function todos(){
        //conexao é um atributo da minha classe
        //query é uma consulta
        return $this->conexao->query("select * from usuarios")->fetchAll(PDO::FETCH_ASSOC);
        // vai retornar uma consulta na base de dados usuarios que vai retornar todos os usuarios, em formato de array associativo.
    }

    public function getUnicoUserById(int $id){
        $this->conexao->query("select * from usuarios where id = {$id}")->fetch(PDO::FETCH_ASSOC);
    }
}

$usuario1 = new Usuario();
$usuario1-> nome = "Jefferson";
$usuario1-> id = 1;
$usuario1->exibe();

//print_r($usuario1);

$usuario2 = new Usuario();
$usuario2-> nome = "Julia";
$usuario2-> id = 2;
$usuario2->exibe();

//print_r($usuario2);

$usuario3 = new Usuario("Matheus", "matheus.quintino", "123");
$usuario3->id = "kiwi";
$usuario3->setNome("Elsa");
$usuario3->usuario = "";
$usuario3->exibe();



//DESISTO POIS N AGUENTO MAIS