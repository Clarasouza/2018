<?php
$conexao = new PDO ("mysql:host=localhost;dbname=bd_filmes","user","senha");
/*

PDO(conceito, classe, entidade)
Try= tenta executar a operação
Catch= captura os erros do bd
*/

$conexao->query("")->fetch("")


/*
Query()= consulta
Fetch()
*/