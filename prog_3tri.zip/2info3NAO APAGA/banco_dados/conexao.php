<?php

    $conexao = new PDO("mysql:host=localhost;dbname=bd_filmes", "root", "root");
    // para usuarios linux a senha é root também
    // nao botar espacos adicionais no "mysql:host...

    $conexao->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);


    //TESTAR SE ACONTECEU UM ERRO DE SQL NO CODIGO, COMO POR EXEMPLO O NOME ERRADO DA TABELA
    try {
        $conexao->exec("INSERT INTO `tb_filme` (`id`, `nome`, `genero`, `classificacao`) VALUES (NULL, 'K-PAX oi oi', 'Aventura', 10)");
    }catch (PDOException $e){

        echo "aconteceu um erro: {$e->getMessage()} na linha {$e->getLine()}";

    }


    try {
        $todos_os_filmes = $conexao->query("SELECT * FROM tb_filme")->fetchAll(PDO::FETCH_ASSOC);
//(PDO::FETCH_ASSOC) para na hpra de mostrar o print r nao vir repetido, pegando so o array asoociativo.
        print_r($todos_os_filmes);

    }catch (PDOException $e){

        echo "aconteceu um erro: {$e->getMessage()} na linha {$e->getLine()}";

    }