

<?php

	$conexao = new PDO("mysql:host=localhost;dbname=bd_filmes", "root", "");
	// para usuarios linux a senha é root também