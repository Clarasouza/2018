	problemas/ folha - estudo dirigido 

1- login: sql injection
solução: filtrar nome de usuario colocado, ou seja, verificar se existe caracteres especiais.

strip... : remove caracteres diversos.
filter_var(qual_variavel_filtrar, qual_tipo_de_filtro);

$nome = filter_var($_POST['usuario'], FILTER_SANITIZE_SPECIAL_CHARS ); (retorna o nome limpo)

$verifica = mysqli_query($conn, "SELECT * FROM usuarios WHERE nome = '{$nome}'
AND senha = '{$senha}'") or die (mysql_error());

2- include de páginas: php injection 
solução: tem haver com a configuração do servidor. 

if(!isset($_GET['pag']) OR !file_exists($_GET['pag'])){
	include 'home.php';
}else if{
	include "{$_GET['pag']}";
}


3- Senha não criptografada
solução: cadastrar a senha de forma criptografada.

$senha_usuario = password_hash($_POST['senha'], PASSWORD_DEFAULT);


$resultado = mysqli_query($conn, "SELECT * FROM usuarios WHERE email = '{$nome_usuario}'") or die ("falhou");

// transformar a consulta SQL em um array associativo
$usuario = mysqli_fetch_assoc($resultado);

// comparar a senha digitada pelo usuario é mesma que esta no banco de daods
$senha_correta = password_verify($_POST['senha'], $usuario['senha']);


if($sehna_correta == true){
	
	$_SESSION['login'] = $_POST['usuario'];
	header("Location: ?pag=seguramca.php");

}else{
	echo 'falga ao logar !!!!!!!!!!!!!!!';
}
}

4- Cadastrar script (alert) : XSS
solução:


5- Dados realizados por get cadastro
solução:
