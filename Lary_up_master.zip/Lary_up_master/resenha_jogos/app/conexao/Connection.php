<?php

class Connection{

    //atributos
    public $connection;

    public function __construct(){

        $this->connection = new PDO("mysql:host=localhost;dbname=resenha_upgrade;", "root", "root"); //caso esteja elo windowa, lembrar de retirar a senha da conexão
        $this->connection->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    }
    public function getConnection(){
        return $this->connection;

    }

}
//Teste
//conexao = new Connection();
//conexao -> getConnection();
// "this->" é
// toda vez que usar a palavra new irão ser usados informações ATRAVÉS do construtor (__ significa 'metodo magico' ou seja não precisa ser chamando ele é acionado pelo NEW)(