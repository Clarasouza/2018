<?php
?>

<!doctype html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Bootstrap CSS -->
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" >

    <title>Hello, world!</title>
  </head>
  <body>

  <div class="container">

        <table class="table">
            <h1>Listagem Usuários</h1>

            <a href="http://localhost/Lary_up_master/resenha_jogos/app/controllers/usuario.php?acao=cadastrar">CADASTRAR</a>

            <thead>
            <tr>
                <th scope="col">#</th>
                <th scope="col">Nome</th>
                <th scope="col">Email</th>
                <th>açoes</th>

            </tr>
            </thead>

            <tbody>
                <?php foreach ($listaUsuarios as $usuario) : ?>
                    <tr>
                        <th scope="col"><?=  $usuario['id']?></th>
                        <th scope="col"><?= $usuario['nome']?></th>
                        <th scope="col"><?= $usuario['email']?></th>
                        <th> 
                            <a href="http://localhost/Lary_up_master/resenha_jogos/app/controllers/usuario.php?acao=editar&id=<?=$usuario['id']?>"> editar </a> 
                            <a href="http://localhost/Lary_up_master/resenha_jogos/app/controllers/usuario.php?acao=excluir&id=<?=$usuario['id']?>"> excluir </a>
                        </th>
                       
                    </tr>

                <?php endforeach; ?>

            </tbody>
        </table>

  </div>

  </body>