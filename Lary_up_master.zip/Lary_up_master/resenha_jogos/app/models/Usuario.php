<?php

require __DIR__."/../conexao/Connection.php";

class Usuario{
    //Atributos da classe
    private $id;
    private $nome;
    private $email;
    private $senha;
    private $tipoUsuario; // 1 para comum e 2 para admin

    public $conexao;

    //Comportamentos

    /**
     * Usuario constructor.
     * @param $nome
     * @param $usuario
     * @param $senha
     * @param null $id
     */
    public function __construct(){
//        $this->id = $id;
//        $this->setNome($nome);
//        $this->usuario = $usuario;
//        $this->senha = $senha;
//        $this->tipoUsuario = 1;0

        $this-> tipoUsuario=1;
        $conexao_objeto = new Connection();

        // o atributo 4 this->Conexao  agora sabe como se comunicar com o banco de dados
        $this->conexao = $conexao_objeto->getConnection();

    }

    public function setId(in $id){
        if(is_int($id)){
            $this->id = $id;
        }
    }

    public function getId(){
        return $this->id;
    }

    public function setNome($nome){

        if (is_string($nome) && strlen($nome) > 2){

            $this->nome = $nome;

        }else{

            echo "informar um nome válido! \n";

        }

    }

    public function exibe(){
        echo "usuario {$this->nome} foi criado com o tipo {$this->tipoUsuario} e id {$this->id} \n";
    }
//flechinha faz com que traga tudo que a função tem a nos oferecer
//FETCHASSOC serve para que os dados venham do banco de dados em formato de array associativo, de fprma que as colunas do bd sejam os indices do array
    public function todos()
    {
        return $this->conexao->query("select * from usuarios")->fetchAll(PDO::FETCH_ASSOC);

    }
      //enquanto o FetchAll retorna um array o Fetch retorna apenas um elemento
        public function getUserById(int $id){
            $user = $this->conexao->query("select * from usuarios where id = {$id} ")-> fetch(PDO::FETCH_ASSOC);
            return $user;
        }

    public function salvar($nome, $email, $senha){

        $sql = "insert into usuarios(nome, email, senha) values('$nome','$email','$senha')";
        $resultado = $this->conexao->exec($sql);
        
        return $resultado;
    }

    public function update($id, $nome, $email, $senha){

        $sql = "update usuarios set nome='$nome', email='$email', senha='$senha' WHERE id=$id";

        $resultado = $this->conexao->exec($sql);

        return $resultado;
    }

    public function delete($id){
        $sql  = "delete from usuarios where id=$id";

        $this->conexao->exec($sql);
    }
}

//$usuario1 = new Usuario();
//$usuario1->nome = "Jefferson";
//$usuario1->id = 1;
//$usuario1-> exibe();
//
//$usuario2 = new Usuario();
//$usuario2-> nome = "Julia";
//$usuario2-> id = 2;
//$usuario2-> exibe();
//
//$usuario3 = new Usuario("Matheus", "matheus.quintino", "123");
//$usuario3->id = "kiwi";
//$usuario3->setNome("Elsa");
//$usuario3->usuario = "";
//$usuario3->exibe();




// como a classe é genérica mão se pode colocar o nome do objeto e nem colocar o this fora da classe
