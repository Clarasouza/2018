oi MORES

<?php

//            Introdução ao Phpmyadmin - "Resenha_upgrade"
//
//-  criação de tabelas de ACORDO COM AS CLASSES JÁ PRÉ - ESTABELECIDAS ANTERIORMENTE
//- ẃ necessaŕios arrumar a conexao
//            1º tabela: usuarios(id, nome, usuario, senha , tipoUsuario)
//            2º
//            3º
//            4º
//            5º
//
//
//
//
//
//



?>