<?php

     $conexao = new PDO("mysql:host=localhost;dbname=bd_filmes", "root", "root");
     //para usuários windows não existe senha

    $conexao -> setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
     $conexao -> setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO:FETCH_ASSOC);
    
try{
   // $conexao-> exec("INSERT INTO `tb_filme` (`id`, `nome`, `genero`, `classificacao`) VALUES (NULL, 'Senho dos anéis: As duas torres.', 'Ficção', '12')");

   $todos_filmes = $conexao -> query("SELECT * FROM tb_filme") -> fetch();
   //FETCH traz uma lista, para melhrar a consulta é necessário colocar um limitante 

   print_r($todos_filmes);

} catch (PDOException $e){

    echo "aconteceu um erro hein: {$e->getMessage()} na linha {$e -> getLine()}";
}

/*
	- fetch : retorna apenas o primeiro da lista;
	- fetchAll retorna uma lista com todos;
	- é necessário usar o fetch para que os dados não venham como uma declaração de consulta;

	- "ARQUITETURA E O PADRÃO E OUTRAS COISAS" 
	- separação entre as telas, controle e entre os modelos;
	- Telas é necessário ter apenas o html, e se necessário usar apenas o php em que não seja necessário muito raciocinio, como por exemplo: (como um for para listar tudo), e separas casos login e verificação se o usuário está na lista ; (VIEW)
	- Modelos: é onde vai estar a sua lógica e seus algoritmos, a parte lógica da sua aplicação, toda tabela que representar um bd vai ser um modelo;(MODEL)
	- (CONTROLLER)
	-  é necessário tentar separar as telas, da parte lógica, da persistencia do banco(manter em sessões de uso),	
	- PACKGIST (https://packagist.org/) - possui vários pacotes prontos para download, como o slugify, composer 
	- começar a trabalhar em aplicações modulares, que seria dividir em partes
*/